from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3, os, hashlib
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'replace_this_with_a_random_key'
DB = os.path.join(os.path.dirname(__file__), "phishing.db")

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def check_password_hash(pw, hashed):
    return hashlib.sha256(pw.encode('utf-8')).hexdigest() == hashed

@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    role = request.form.get('role')
    email = request.form.get('email')
    password = request.form.get('password')
    if not role or not email or not password:
        flash('Please fill in all fields.', 'error')
        return redirect(url_for('index'))

    conn = get_db()
    cur = conn.cursor()
    if role == 'admin':
        cur.execute("SELECT * FROM admin WHERE email = ?", (email,))
        user = cur.fetchone()
        if user and check_password_hash(password, user['password']):
            session['role'] = 'admin'
            session['user'] = user['name']
            conn.close()
            return redirect(url_for('admin_dashboard'))
        else:
            conn.close()
            flash('Invalid admin credentials', 'error')
            return redirect(url_for('index'))
    else:
        cur.execute("SELECT * FROM employees WHERE email = ?", (email,))
        user = cur.fetchone()
        if user and check_password_hash(password, user['password']):
            session['role'] = 'employee'
            session['user'] = user['name']
            session['employee_id'] = user['id']
            conn.close()
            return redirect(url_for('employee_inbox'))
        else:
            conn.close()
            flash('Invalid employee credentials', 'error')
            return redirect(url_for('index'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/admin-dashboard')
def admin_dashboard():
    if session.get('role')!='admin':
        return redirect(url_for('index'))
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT COUNT(*) as cnt FROM campaigns")
    total_campaigns = cur.fetchone()['cnt']
    cur.execute("SELECT COUNT(*) as cnt FROM employees")
    total_employees = cur.fetchone()['cnt']
    cur.execute("SELECT * FROM campaigns ORDER BY id DESC LIMIT 5")
    campaigns = cur.fetchall()
    conn.close()
    return render_template('admin-dashboard.html', total_campaigns=total_campaigns, total_employees=total_employees, campaigns=campaigns)

@app.route('/create-campaign', methods=['GET','POST'])
def create_campaign():
    if session.get('role')!='admin':
        return redirect(url_for('index'))
    conn = get_db(); cur = conn.cursor()
    if request.method=='POST':
        name = request.form.get('name')
        template = request.form.get('template')
        schedule = request.form.get('schedule')
        cur.execute("INSERT INTO campaigns (name,template,schedule) VALUES (?,?,?)", (name,template,schedule))
        conn.commit()
        conn.close()
        return redirect(url_for('admin_dashboard'))
    cur.execute("SELECT * FROM employees")
    employees = cur.fetchall()
    conn.close()
    return render_template('create-campaign.html', employees=employees)

@app.route('/manage-employees', methods=['GET','POST'])
def manage_employees():
    if session.get('role')!='admin':
        return redirect(url_for('index'))
    conn = get_db(); cur = conn.cursor()
    if request.method=='POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        dept = request.form.get('department')
        hashed = hashlib.sha256(password.encode('utf-8')).hexdigest()
        cur.execute("INSERT INTO employees (name,email,password,department) VALUES (?,?,?,?)", (name,email,hashed,dept))
        conn.commit()
    cur.execute("SELECT * FROM employees")
    employees = cur.fetchall()
    conn.close()
    return render_template('manage-employees.html', employees=employees)

@app.route('/reports')
def reports():
    if session.get('role')!='admin':
        return redirect(url_for('index'))
    conn = get_db(); cur = conn.cursor()
    cur.execute("""
        SELECT c.id, c.name, COUNT(r.id) as total_responses,
        SUM(CASE WHEN r.action='clicked' THEN 1 ELSE 0 END) as clicked,
        SUM(CASE WHEN r.action='reported' THEN 1 ELSE 0 END) as reported
        FROM campaigns c LEFT JOIN responses r ON c.id=r.campaign_id
        GROUP BY c.id
    """)
    rows = cur.fetchall()
    conn.close()
    return render_template('reports.html', rows=rows)

@app.route('/employee-inbox', methods=['GET','POST'])
def employee_inbox():
    if session.get('role')!='employee':
        return redirect(url_for('index'))
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT * FROM campaigns ORDER BY id DESC")
    campaigns = cur.fetchall()
    cur.execute("SELECT * FROM employees WHERE id=?", (session.get('employee_id'),))
    emp = cur.fetchone()
    conn.close()
    return render_template('employee-inbox.html', campaigns=campaigns, employee=emp)

@app.route('/respond', methods=['POST'])
def respond():
    if session.get('role')!='employee':
        return redirect(url_for('index'))
    emp_id = session.get('employee_id')
    campaign_id = request.form.get('campaign')
    action = request.form.get('action')
    timestamp = datetime.now().isoformat()
    conn = get_db(); cur = conn.cursor()
    cur.execute("INSERT INTO responses (employee_id,campaign_id,action,timestamp) VALUES (?,?,?,?)", (emp_id,campaign_id,action,timestamp))
    conn.commit(); conn.close()
    return redirect(url_for('feedback', action=action))

@app.route('/feedback')
def feedback():
    if session.get('role') not in ['employee','admin']:
        return redirect(url_for('index'))
    action = request.args.get('action','')
    return render_template('feedback.html', action=action)

@app.route('/training')
def training():
    if session.get('role') not in ['employee','admin']:
        return redirect(url_for('index'))
    return render_template('training.html')

@app.route('/profile')
def profile():
    if session.get('role') not in ['employee','admin']:
        return redirect(url_for('index'))
    return render_template('profile.html')

if __name__ == '__main__':
    app.run(debug=True)
