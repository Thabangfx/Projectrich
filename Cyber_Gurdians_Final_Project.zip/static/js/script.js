document.addEventListener('DOMContentLoaded', () => {
  const adminBtn = document.getElementById('adminRoleBtn');
  const empBtn = document.getElementById('empRoleBtn');
  const roleInput = document.getElementById('roleInput');
  if (adminBtn) {
    adminBtn.addEventListener('click', () => {
      roleInput.value = 'admin';
      adminBtn.classList.add('btn-active');
      empBtn.classList.remove('btn-active');
    });
  }
  if (empBtn) {
    empBtn.addEventListener('click', () => {
      roleInput.value = 'employee';
      empBtn.classList.add('btn-active');
      adminBtn.classList.remove('btn-active');
    });
  }
});
