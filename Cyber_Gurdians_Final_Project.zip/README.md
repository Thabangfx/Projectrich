See README in project root. Run with python app.py after installing Flask.
